from enum import Enum

class SearchType(Enum):
    EXACT_NAME = 0
    FIRST_MIDDLE_INITIAL = 1
    FIRST_INITIAL = 2